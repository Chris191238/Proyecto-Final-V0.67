<?php
class Venta{
    public $id;
    public $fecha;
    public $total;
}
?>
