<?php
class Detalle{
    public $id;
    public $nomProducto;
    public $cantidad;
    public $subTotal;
    public $precio;
}
?>
