<?php
class Conexion{
    private $mysql;
    private $bdName;
    private $user;
    private $pass;

    public function __construct($bdName){
        $this->bdName = $bdName;
        $this->user = "id16738421_root";
        $this->pass = "SenAdo_93#WEFWE";
    }

    public function conectar(){
        $this->mysqli = new mysqli(
            "localhost",
            $this->user,
            $this->pass,
            $this->bdName
        );

        if (mysqli_connect_errno()) {
            printf("Error de conexión: %s\n", mysqli_connect_error());
            exit();
        }
    }

    public function ejecutar($query){
        return $this->mysqli->query($query);
    }

    public function desconectar(){
        $this->mysqli->close();
    }
}
?>
