<?php
$conn = new mysqli("localhost","id16738421_rooot","SenAdo_93#WEFWE","id16738421_loginvaidroll5");
	
	if($conn->connect_errno)
	{
		echo "No hay conexión: (" . $conn->connect_errno . ") " . $conn->connect_error;
	}
?>